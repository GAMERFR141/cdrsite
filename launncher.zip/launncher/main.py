import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import json
import smtplib
from email.message import EmailMessage
import os
from datetime import datetime

# Configuration par défaut
default_config = {
    "smtp_email": "cdrgestion1@gmail.com",
    "smtp_password": "svce qosl jhnr kevf",
    "smtp_server": "smtp.gmail.com",
    "smtp_port": 587,
    "theme": "basic",
    "mode": "day",
    "access_code_encrypted": "",
    "cypher_key": "ma_clef123"
}

CONFIG_FILE = "settings.json"
PEOPLE_FILE = "people.json"
AGENDA_FILE = "agenda.json"


def load_config():
    if not os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'w') as f:
            json.dump(default_config, f, indent=4)
    with open(CONFIG_FILE, 'r') as f:
        return json.load(f)


def save_config(config):
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=4)


def load_people():
    if not os.path.exists(PEOPLE_FILE):
        with open(PEOPLE_FILE, 'w') as f:
            json.dump([], f)
    with open(PEOPLE_FILE, 'r') as f:
        return json.load(f)


def save_people(people):
    with open(PEOPLE_FILE, 'w') as f:
        json.dump(people, f, indent=4)


def load_agenda():
    if not os.path.exists(AGENDA_FILE):
        with open(AGENDA_FILE, 'w') as f:
            json.dump([], f)
    with open(AGENDA_FILE, 'r') as f:
        return json.load(f)


def save_agenda(events):
    with open(AGENDA_FILE, 'w') as f:
        json.dump(events, f, indent=4)


class CDRManagerApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("CDR Manager")
        self.geometry("900x600")
        self.load_all_data()

        self.container = tk.Frame(self)
        self.container.pack(fill="both", expand=True)

        self.frames = {}
        for F in (StartPage, LoginPage, MainPage, SettingsPage):
            frame = F(self.container, self)
            self.frames[F] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        if not self.config.get("access_code_encrypted"):
            self.ask_new_access_code()

        self.show_frame(StartPage)

    def load_all_data(self):
        self.config = load_config()
        self.people = load_people()
        self.agenda = load_agenda()
        self.check_vars = {}

    def reset_app(self):
        for f in [CONFIG_FILE, PEOPLE_FILE, AGENDA_FILE]:
            try:
                if os.path.exists(f):
                    os.remove(f)
            except Exception as e:
                messagebox.showerror("Erreur", f"Impossible de supprimer {f}:\n{e}")
                return
        self.load_all_data()
        self.frames[MainPage].refresh_people()
        self.frames[MainPage].refresh_agenda()
        messagebox.showinfo("Réinitialisation", "L'application a été réinitialisée.")
        self.show_frame(StartPage)

    def show_frame(self, page):
        frame = self.frames[page]
        frame.tkraise()

    def ask_new_access_code(self):
        code = simpledialog.askstring("Nouveau code d'accès",
                                      "Aucun code d'accès trouvé.\nEntrez un nouveau code d'accès :",
                                      show="*")
        if code:
            self.config["access_code_encrypted"] = code
            save_config(self.config)
            messagebox.showinfo("Info", "Code d'accès créé avec succès.")
        else:
            messagebox.showwarning("Attention", "Vous devez saisir un code d'accès !")
            self.ask_new_access_code()


class StartPage(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        label = tk.Label(self, text="🚀 CDR MANAGER", font=("Helvetica", 32))
        label.pack(pady=100)
        btn = tk.Button(self, text="Entrer le code", command=lambda: controller.show_frame(LoginPage))
        btn.pack()


class LoginPage(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        tk.Label(self, text="Entrer le code d'accès:").pack(pady=20)
        self.code_entry = tk.Entry(self, show="*")
        self.code_entry.pack()
        tk.Button(self, text="Valider", command=self.check_code).pack(pady=10)

    def check_code(self):
        code = self.code_entry.get()
        if code == self.controller.config['access_code_encrypted']:
            self.controller.show_frame(MainPage)
        else:
            messagebox.showerror("Erreur", "Code incorrect")


class MainPage(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        top_frame = tk.Frame(self)
        top_frame.pack(side="top", fill="x", pady=10)

        tk.Button(top_frame, text="Paramètres", command=lambda: controller.show_frame(SettingsPage)).pack(side="right", padx=5)
        tk.Button(top_frame, text="Ajouter personne", command=self.add_person).pack(side="left", padx=5)
        tk.Button(top_frame, text="Supprimer personne", command=self.remove_person).pack(side="left", padx=5)

        self.people_frame = tk.Frame(self)
        self.people_frame.pack(pady=10)

        tk.Button(self, text="Envoyer", command=self.send_email).pack(pady=10)

        tk.Label(self, text="Agenda").pack(pady=(20, 5))
        self.agenda_frame = tk.Frame(self)
        self.agenda_frame.pack()
        tk.Button(self, text="Ajouter événement", command=self.add_event).pack(pady=5)

        self.refresh_people()
        self.refresh_agenda()

    def refresh_people(self):
        for widget in self.people_frame.winfo_children():
            widget.destroy()

        self.controller.check_vars.clear()
        for person in self.controller.people:
            var = tk.BooleanVar()
            chk = tk.Checkbutton(self.people_frame, text=person, variable=var)
            chk.pack(anchor='w')
            self.controller.check_vars[person] = var

    def add_person(self):
        name = tk.simpledialog.askstring("Ajouter personne", "Nom:")
        if name:
            self.controller.people.append(name)
            save_people(self.controller.people)
            self.refresh_people()

    def remove_person(self):
        name = tk.simpledialog.askstring("Supprimer personne", "Nom de la personne à supprimer:")
        if name in self.controller.people:
            self.controller.people.remove(name)
            save_people(self.controller.people)
            self.refresh_people()
        else:
            messagebox.showwarning("Avertissement", "Personne non trouvée")

    def send_email(self):
        absent_list = [p for p, var in self.controller.check_vars.items() if not var.get()]
        if not absent_list:
            messagebox.showinfo("Info", "Tout le monde est présent !")
            return

        config = self.controller.config

        msg = EmailMessage()
        msg['Subject'] = 'Absents CDR'
        msg['From'] = config['smtp_email']
        msg['To'] = config['smtp_email']
        msg.set_content("Personnes absentes :\n" + "\n".join(absent_list))

        try:
            with smtplib.SMTP(config['smtp_server'], config['smtp_port']) as server:
                server.starttls()
                server.login(config['smtp_email'], config['smtp_password'])
                server.send_message(msg)
            messagebox.showinfo("Succès", "Email envoyé avec succès !")
        except Exception as e:
            messagebox.showerror("Erreur", str(e))

    def refresh_agenda(self):
        for widget in self.agenda_frame.winfo_children():
            widget.destroy()

        for event in self.controller.agenda:
            tk.Label(self.agenda_frame, text=event).pack(anchor='w')

    def add_event(self):
        event = tk.simpledialog.askstring("Nouvel événement", "Détail de l'événement:")
        if event:
            timestamp = datetime.now().strftime("%d/%m/%Y %H:%M")
            self.controller.agenda.append(f"{timestamp} - {event}")
            save_agenda(self.controller.agenda)
            self.refresh_agenda()


class SettingsPage(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        tk.Label(self, text="Paramètres SMTP").pack(pady=10)
        self.email_entry = self.create_entry("Email", controller.config['smtp_email'])
        self.pass_entry = self.create_entry("Mot de passe d'application", controller.config['smtp_password'], show="*")
        self.server_entry = self.create_entry("Serveur SMTP", controller.config['smtp_server'])
        self.port_entry = self.create_entry("Port", controller.config['smtp_port'])

        tk.Label(self, text="Style").pack(pady=10)
        self.mode_var = tk.StringVar(value=controller.config['mode'])
        ttk.Combobox(self, textvariable=self.mode_var, values=["day", "night"]).pack()

        self.theme_var = tk.StringVar(value=controller.config['theme'])
        ttk.Combobox(self, textvariable=self.theme_var, values=["basic", "futurist"]).pack()

        button_frame = tk.Frame(self)
        button_frame.pack(pady=20)

        tk.Button(button_frame, text="Sauvegarder", command=self.save_settings).pack(side="left", padx=10)
        tk.Button(button_frame, text="Réinitialiser", fg="red", command=self.reset_app).pack(side="left", padx=10)
        tk.Button(button_frame, text="Retour", command=lambda: controller.show_frame(MainPage)).pack(side="left", padx=10)

    def create_entry(self, label, default, show=None):
        tk.Label(self, text=label).pack()
        entry = tk.Entry(self, show=show) if show else tk.Entry(self)
        entry.insert(0, str(default))
        entry.pack()
        return entry

    def save_settings(self):
        config = self.controller.config
        config['smtp_email'] = self.email_entry.get()
        config['smtp_password'] = self.pass_entry.get()
        config['smtp_server'] = self.server_entry.get()
        config['smtp_port'] = int(self.port_entry.get())
        config['mode'] = self.mode_var.get()
        config['theme'] = self.theme_var.get()
        save_config(config)
        messagebox.showinfo("Info", "Paramètres sauvegardés")

    def reset_app(self):
        answer = messagebox.askyesno("Confirmation", "Voulez-vous vraiment réinitialiser l'application ?\nCette action supprimera toutes les données.")
        if answer:
            self.controller.reset_app()


if __name__ == "__main__":
    app = CDRManagerApp()
    app.mainloop()