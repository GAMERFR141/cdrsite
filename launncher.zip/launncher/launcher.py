import tkinter as tk
import subprocess

def run_bat(bat_file):
    # Lance le fichier .bat avec la commande shell
    subprocess.Popen(bat_file, shell=True)

root = tk.Tk()
root.attributes('-fullscreen', True)  # Plein écran

# Exemple avec 2 fichiers .bat à lancer
bat_files = ["run_gestion.bat", "run_cdr_cipher.bat",]

for bat in bat_files:
    btn = tk.Button(root, text=f"Lancer {bat}", command=lambda b=bat: run_bat(b), font=("Arial", 24))
    btn.pack(pady=20)

# Bouton pour quitter le launcher
quit_btn = tk.Button(root, text="Quitter", command=root.destroy, font=("Arial", 24), bg="red", fg="white")
quit_btn.pack(pady=40)

root.mainloop()