import tkinter as tk
from tkinter import messagebox

# Alphabet CDRCODE avec caractères spéciaux et chiffres
alphabet_cdr = {
    'a': '∆⊗', 'b': 'Ω♠', 'c': 'λ∇', 'd': 'π♣', 'e': 'φ♢',
    'f': 'θ∞', 'g': 'ψ⊕', 'h': 'ζ≡', 'i': 'η⊥', 'j': 'ξ≡',
    'k': 'κΣ', 'l': 'α⊖', 'm': 'μ⊞', 'n': 'ν∣', 'o': 'ωΘ',
    'p': 'π²↑', 'q': 'χ∧', 'r': 'ρΘ', 's': 'σΩ', 't': 'τδ',
    'u': 'υϒ', 'v': 'β⊂', 'w': 'ω²∈', 'x': 'ψ²≀', 'y': 'γψ',
    'z': 'ζ²Λ',
    'A': '∆∆', 'B': 'ΩΩ', 'C': 'λλ', 'D': 'ππ', 'E': 'φφ',
    'F': 'θθ', 'G': 'ψψ', 'H': 'ζζ', 'I': 'ηη', 'J': 'ξξ',
    'K': 'κκ', 'L': 'αα', 'M': 'μμ', 'N': 'νν', 'O': 'ωω',
    'P': 'ππ', 'Q': 'χχ', 'R': 'ρρ', 'S': 'σσ', 'T': 'ττ',
    'U': 'υυ', 'V': 'ββ', 'W': 'ωω', 'X': 'ψψ', 'Y': 'γγ',
    'Z': 'ζζ', '0': 'ϟϟ', '1': 'αα', '2': 'ββ', '3': 'γγ',
    '4': 'δδ', '5': 'εε', '6': 'ζζ', '7': 'ηη', '8': 'θθ', 
    '9': 'ιι', '!': '∑!', '@': '∞@', '#': '∇#', '$': '⊗$', 
    '%': 'Ω%', '^': 'λ^', '&': '♣&', '*': '⊕*', '(': '⊖(', 
    ')': '♢)', '-': '↔-', '_': '⇔_', '=': '≡=', '+': '⊕+', 
    '[': '⟦[', ']': '⟧]', '{': '⟨{', '}': '⟩}', ';': '⋄;', 
    ':': '⧫:', "'": '∥\'', '"': '⊣"', '<': '≤<', '>': '≥>',
    '?': '⍰?', '/': '⌿/', '.': '∎.', ',': '∶,'
}

# Inverser le dictionnaire pour déchiffrement
alphabet_cdr_inverse = {v: k for k, v in alphabet_cdr.items()}


class CDRCODECipherApp:
    def __init__(self, root):
        self.root = root
        self.root.title("CDRCODE CIPHER")
        self.root.geometry("900x700")
        self.configure_dark_mode()
        self.create_ui()

    def configure_dark_mode(self):
        # Couleurs pour le mode sombre
        self.bg_color = "#121212"
        self.fg_color = "#bb86fc"
        self.text_bg = "#2c2c2c"
        self.text_fg = "#ffffff"
        self.btn_traduire_color = "#ff5722"  # Couleur vibrante pour Traduire
        self.btn_decrypter_color = "#03a9f4"  # Couleur vibrante pour Déchiffrer
        self.btn_inverser_color = "#8bc34a"  # Couleur vibrante pour Inverser Résultat
        self.btn_reset_color = "#e91e63"  # Couleur vibrante pour Réinitialiser
        self.btn_copier_color = "#ffc107"  # Couleur vibrante pour Copier
        self.filigrane_color = "#7a7a7a"

    def create_ui(self):
        # Frame principal
        self.main_frame = tk.Frame(self.root, bg=self.bg_color)
        self.main_frame.pack(fill=tk.BOTH, expand=True)

        # Titre
        self.titre = tk.Label(self.main_frame, text="Bienvenue dans CDRCODE CIPHER", font=("Helvetica", 18, "bold"),
                              bg=self.bg_color, fg=self.fg_color)
        self.titre.pack(pady=10)

        # Texte entrée
        self.texte_entree = tk.Text(self.main_frame, height=8, width=60, font=("Courier", 12),
                                    bg=self.text_bg, fg=self.text_fg, insertbackground=self.text_fg)
        self.texte_entree.pack(pady=10)

        # Boutons d'action
        self.bouton_frame = tk.Frame(self.main_frame, bg=self.bg_color)
        self.bouton_frame.pack(pady=10)

        self.btn_traduire = tk.Button(self.bouton_frame, text="Traduire", command=self.traduire, bg=self.btn_traduire_color,
                                      fg="white", font=("Arial", 12), width=12)
        self.btn_traduire.grid(row=0, column=0, padx=5)

        self.btn_decrypter = tk.Button(self.bouton_frame, text="Déchiffrer", command=self.decrypter, bg=self.btn_decrypter_color,
                                       fg="white", font=("Arial", 12), width=12)
        self.btn_decrypter.grid(row=0, column=1, padx=5)

        self.btn_inverser = tk.Button(self.bouton_frame, text="Inverser Résultat", command=self.inverser_resultat,
                                      bg=self.btn_inverser_color, fg="white", font=("Arial", 12), width=15)
        self.btn_inverser.grid(row=0, column=2, padx=5)

        self.btn_reset = tk.Button(self.bouton_frame, text="Réinitialiser", command=self.reinitialiser,
                                   bg=self.btn_reset_color, fg="white", font=("Arial", 12), width=12)
        self.btn_reset.grid(row=1, column=0, columnspan=3, pady=10)

        # Texte sortie
        self.sortie_resultat = tk.Text(self.main_frame, height=8, width=60, font=("Courier", 12),
                                       bg=self.text_bg, fg=self.text_fg, insertbackground=self.text_fg)
        self.sortie_resultat.pack(pady=10)

        # Bouton copier
        self.btn_copier = tk.Button(self.main_frame, text="Copier dans le Presse-papier", command=self.copier_resultat,
                                    bg=self.btn_copier_color, fg="white", font=("Arial", 12), width=30)
        self.btn_copier.pack(pady=10)

        # Filigrane
        self.filigrane = tk.Label(self.main_frame,
                                  text="Propriété du Clan Du Renard et de la Shadow Corporation\nCréé et rajouté par Emrys Hardy",
                                  font=("Helvetica", 10, "italic"), bg=self.bg_color, fg=self.filigrane_color)
        self.filigrane.pack(side=tk.BOTTOM, pady=10)

    def traduire(self):
        texte = self.texte_entree.get("1.0", tk.END).strip()
        result = ''.join(alphabet_cdr.get(char, char) for char in texte)
        self.sortie_resultat.delete("1.0", tk.END)
        self.sortie_resultat.insert("1.0", result)

    def decrypter(self):
        texte = self.texte_entree.get("1.0", tk.END).strip()
        for symbole, lettre in alphabet_cdr_inverse.items():
            texte = texte.replace(symbole, lettre)
        self.sortie_resultat.delete("1.0", tk.END)
        self.sortie_resultat.insert("1.0", texte)

    def inverser_resultat(self):
        resultat = self.sortie_resultat.get("1.0", tk.END).strip()
        self.sortie_resultat.delete("1.0", tk.END)
        self.sortie_resultat.insert("1.0", resultat[::-1])

    def reinitialiser(self):
        self.texte_entree.delete("1.0", tk.END)
        self.sortie_resultat.delete("1.0", tk.END)

    def copier_resultat(self):
        resultat = self.sortie_resultat.get("1.0", tk.END).strip()
        self.root.clipboard_clear()
        self.root.clipboard_append(resultat)
        self.root.update()
        messagebox.showinfo("Succès", "Résultat copié dans le presse-papier !")


if __name__ == "__main__":
    root = tk.Tk()
    app = CDRCODECipherApp(root)
    root.mainloop()
